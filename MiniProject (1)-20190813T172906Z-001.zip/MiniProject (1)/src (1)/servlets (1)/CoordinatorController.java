package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.protocol.x.Notice;

import entities.Coordinator;
import entities.Project;
import entities.Student;
import jdbc_student.Jdbc;

/**
 * Servlet implementation class CoordinatorController
 */
@WebServlet("/CoordinatorController")
public class CoordinatorController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CoordinatorController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String coordinator_id=request.getParameter("user_id");
		System.out.println("inside coordinator colntroller "+coordinator_id);
		HttpSession session=request.getSession();
		Coordinator coordinator=new Coordinator();
		Jdbc newcoordinator=new Jdbc();
		coordinator=newcoordinator.coordinatorInformation(coordinator_id);
		session.setAttribute("coordinator_info",coordinator);
		String year_id=request.getParameter("year_selected");
		String notice_desc=request.getParameter("notice_description");

		System.out.println("herre 0");
		if(year_id!=null)
		{
			System.out.println("herre 1");
			Jdbc project_year=new Jdbc();
			List<Project>project_year_list=project_year.listArchivesProjectsAll(year_id);
			session.setAttribute("project_year_list",project_year_list);
		}
		else
			session.setAttribute("project_year_list", null);
		
		if(notice_desc!=null)
		{
			System.out.println("herre 2");
			Jdbc notice_add=new Jdbc();
			entities.Notice notice=new entities.Notice();
			notice.setNotice_description(notice_desc);
			notice.setCoordinator_id(coordinator_id);
			notice_add.insertNotice(notice);			
		}
		response.sendRedirect("WelcomeCoordinator.jsp");
	}

}
