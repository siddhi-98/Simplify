package entities;

public class Review1 {
	private String review1_id;
	private int review1_marks;
	private String review1_comment;
	
	public String getReview1_comment() {
		return review1_comment;
	}
	public void setReview1_comment(String review1_comment) {
		this.review1_comment = review1_comment;
	}

	public String getReview1_id() {
		return review1_id;
	}
	public void setReview1_id(String review1_id) {
		this.review1_id = review1_id;
	}
	public int getReview1_marks() {
		return review1_marks;
	}
	public void setReview1_marks(int review1_marks) {
		this.review1_marks = review1_marks;
	}
}
