package entities;

public class Review3 {
	private String review3_id;
	private int review3_marks;
	private String review3_comment;
	
	public String getReview3_comment() {
		return review3_comment;
	}
	public void setReview3_comment(String review3_comment) {
		this.review3_comment = review3_comment;
	}
	public String getReview3_id() {
		return review3_id;
	}
	public void setReview3_id(String review3_id) {
		this.review3_id = review3_id;
	}
	public int getReview3_marks() {
		return review3_marks;
	}
	public void setReview3_marks(int review3_marks) {
		this.review3_marks = review3_marks;
	}
}
