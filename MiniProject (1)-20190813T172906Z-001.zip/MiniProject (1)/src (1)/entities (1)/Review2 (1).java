package entities;

public class Review2 {
	private String review2_id;
	private int review2_marks;
	private String review2_comment;
	
	public String getReview2_comment() {
		return review2_comment;
	}
	public void setReview2_comment(String review2_comment) {
		this.review2_comment = review2_comment;
	}

	public String getReview2_id() {
		return review2_id;
	}
	public void setReview2_id(String review2_id) {
		this.review2_id = review2_id;
	}
	public int getReview2_marks() {
		return review2_marks;
	}
	public void setReview2_marks(int review2_marks) {
		this.review2_marks = review2_marks;
	}
}
