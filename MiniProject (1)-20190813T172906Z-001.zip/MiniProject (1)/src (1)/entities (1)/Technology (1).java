package entities;

public class Technology {
	private String technology_id;
	private String technology_name;
	
	public String getTechnology_id() {
		return technology_id;
	}
	public void setTechnology_id(String technology_id) {
		this.technology_id = technology_id;
	}
	public String getTechnology_name() {
		return technology_name;
	}
	public void setTechnology_name(String technology_name) {
		this.technology_name = technology_name;
	}
	
}
